CREATE TABLE `participants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`uid` varchar(32) NOT NULL,
	`name` varchar(120),
	`photoUrl` text NOT NULL,
	`photoKey` varchar(512) NOT NULL,
	`status` enum('pending','approved','rejected','hidden') NOT NULL DEFAULT 'approved',
	`consent` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `participants_id` PRIMARY KEY(`id`),
	CONSTRAINT `participants_uid_unique` UNIQUE(`uid`)
);
