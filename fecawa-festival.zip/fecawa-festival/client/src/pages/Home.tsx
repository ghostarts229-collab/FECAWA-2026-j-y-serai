import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  ArrowDown,
  ArrowUpRight,
  Check,
  ChevronRight,
  CircleAlert,
  Copy,
  Download,
  ImagePlus,
  Link2,
  Instagram,
  Menu,
  MessageCircle,
  Share2,
  Sparkles,
  Upload,
  X,
} from "lucide-react";
import { trpc } from "@/lib/trpc";

type Participant = {
  id: number;
  uid: string;
  name: string | null;
  photoUrl: string;
  createdAt: Date;
};

const OFFICIAL_POSTER_URL = "/manus-storage/fecawa-official_a5f34f3c.webp";

const navItems = [
  { label: "Accueil", href: "#accueil" },
  { label: "Le festival", href: "#festival" },
  { label: "J’y serai", href: "#participer" },
  { label: "Participants", href: "#participants" },
  { label: "Contact", href: "#contact" },
];

const isAcceptedImage = (file: File) =>
  ["image/jpeg", "image/png", "image/webp"].includes(file.type);

const compressSquareImage = (file: File) =>
  new Promise<string>((resolve, reject) => {
    const image = new Image();
    const objectUrl = URL.createObjectURL(file);
    image.onload = () => {
      const side = Math.min(image.naturalWidth, image.naturalHeight);
      const sx = (image.naturalWidth - side) / 2;
      const sy = (image.naturalHeight - side) / 2;
      const canvas = document.createElement("canvas");
      canvas.width = 900;
      canvas.height = 900;
      const context = canvas.getContext("2d");
      if (!context) {
        URL.revokeObjectURL(objectUrl);
        reject(new Error("Impossible de préparer cette image."));
        return;
      }
      context.drawImage(image, sx, sy, side, side, 0, 0, 900, 900);
      URL.revokeObjectURL(objectUrl);
      resolve(canvas.toDataURL("image/jpeg", 0.82));
    };
    image.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error("Cette image ne peut pas être lue."));
    };
    image.src = objectUrl;
  });

function OfficialPoster() {
  return (
    <div className="official-poster" aria-label="Affiche officielle du FECAWA">
      <img src={OFFICIAL_POSTER_URL} alt="Affiche officielle du FECAWA — du 19 au 21 novembre 2026 à Natitingou" />
    </div>
  );
}

const loadImage = (src: string) => new Promise<HTMLImageElement>((resolve, reject) => {
  const image = new Image();
  image.crossOrigin = "anonymous";
  image.onload = () => resolve(image);
  image.onerror = () => reject(new Error("Impossible de charger l’image officielle."));
  image.src = src;
});

async function renderPosterDataUrl(photoUrl: string) {
  const [poster, photo] = await Promise.all([loadImage(OFFICIAL_POSTER_URL), loadImage(photoUrl)]);
  const canvas = document.createElement("canvas");
  canvas.width = poster.naturalWidth;
  canvas.height = poster.naturalHeight;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas indisponible.");
  context.drawImage(poster, 0, 0);

  // Zone du portrait du monsieur dans l’affiche reçue : les autres pixels restent inchangés.
  const photoX = 151;
  const photoY = 386;
  const photoWidth = 744;
  const photoHeight = 1310;
  const topLeftRadius = 118;
  const topRightRadius = 10;
  const bottomRightRadius = 16;
  const bottomLeftRadius = 82;
  const scale = Math.max(photoWidth / photo.naturalWidth, photoHeight / photo.naturalHeight);
  const drawWidth = photo.naturalWidth * scale;
  const drawHeight = photo.naturalHeight * scale;
  const drawX = photoX + (photoWidth - drawWidth) / 2;
  const drawY = photoY + (photoHeight - drawHeight) / 2;
  context.save();
  context.beginPath();
  context.moveTo(photoX + topLeftRadius, photoY);
  context.lineTo(photoX + photoWidth - topRightRadius, photoY);
  context.arcTo(photoX + photoWidth, photoY, photoX + photoWidth, photoY + topRightRadius, topRightRadius);
  context.lineTo(photoX + photoWidth, photoY + photoHeight - bottomRightRadius);
  context.arcTo(photoX + photoWidth, photoY + photoHeight, photoX + photoWidth - bottomRightRadius, photoY + photoHeight, bottomRightRadius);
  context.lineTo(photoX + bottomLeftRadius, photoY + photoHeight);
  context.arcTo(photoX, photoY + photoHeight, photoX, photoY + photoHeight - bottomLeftRadius, bottomLeftRadius);
  context.lineTo(photoX, photoY + topLeftRadius);
  context.arcTo(photoX, photoY, photoX + topLeftRadius, photoY, topLeftRadius);
  context.closePath();
  context.clip();
  context.drawImage(photo, drawX, drawY, drawWidth, drawHeight);
  context.restore();
  return canvas.toDataURL("image/jpeg", 0.94);
}

function ParticipationModal({
  onClose,
  onSuccess,
}: {
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [name, setName] = useState("");
  const [imageData, setImageData] = useState("");
  const [preview, setPreview] = useState("");
  const [consent, setConsent] = useState(false);
  const [submittedParticipant, setSubmittedParticipant] = useState<Participant | null>(null);
  const [error, setError] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const submit = trpc.participants.submit.useMutation({
    onSuccess: (data) => {
      toast.success("Ta participation a bien été ajoutée à la galerie.");
      setSubmittedParticipant(data.participant as Participant);
      onSuccess();
    },
    onError: (mutationError) => setError(mutationError.message || "Une erreur est survenue. Réessaie."),
  });

  const handleFile = async (file?: File) => {
    setError("");
    if (!file) return;
    if (!isAcceptedImage(file)) {
      setError("Formats acceptés : JPG, JPEG, PNG ou WebP.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError("La photo doit faire moins de 10 Mo.");
      return;
    }
    try {
      const compressed = await compressSquareImage(file);
      setImageData(compressed);
      setPreview(compressed);
    } catch (compressionError) {
      setError(compressionError instanceof Error ? compressionError.message : "Impossible de préparer la photo.");
    }
  };

  const handleSubmit = () => {
    if (!imageData) {
      setError("Ajoute une photo pour continuer.");
      return;
    }
    if (!consent) {
      setError("Confirme ton accord pour publier ta photo dans la galerie.");
      return;
    }
    setError("");
    submit.mutate({
      name: name.trim() || undefined,
      imageData,
      consent: true,
    });
  };

  const downloadPoster = async () => {
    if (!submittedParticipant) return;
    try {
      const posterDataUrl = await renderPosterDataUrl(submittedParticipant.photoUrl);
      const link = document.createElement("a");
      link.download = "fecawa-j-y-serai.jpg";
      link.href = posterDataUrl;
      link.click();
      toast.success("Ton affiche personnalisée est téléchargée.");
    } catch {
      toast.error("Impossible de préparer l’affiche. Réessaie.");
    }
  };

  const sharePoster = async (channel: "whatsapp" | "facebook" | "copy") => {
    const shareText = "J’y serai au FECAWA – Festival des Arts et de la Culture Waama !";
    const shareUrl = `${window.location.origin}/#participants`;
    if (channel === "whatsapp" && submittedParticipant) {
      try {
        const posterDataUrl = await renderPosterDataUrl(submittedParticipant.photoUrl);
        const response = await fetch(posterDataUrl);
        const file = new File([await response.blob()], "fecawa-j-y-serai.jpg", { type: "image/jpeg" });
        if (navigator.canShare?.({ files: [file] })) {
          await navigator.share({ files: [file], title: "FECAWA — J’y serai", text: shareText });
          return;
        }
      } catch {
        // Fallback to the regular WhatsApp link when native file sharing is unavailable.
      }
    }
    if (channel === "whatsapp") window.open(`https://wa.me/?text=${encodeURIComponent(`${shareText} ${shareUrl}`)}`, "_blank", "noopener,noreferrer");
    if (channel === "facebook") window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, "_blank", "noopener,noreferrer");
    if (channel === "copy") {
      await navigator.clipboard?.writeText(shareUrl);
      toast.success("Lien de partage copié.");
    }
  };

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <div className="participation-modal" role="dialog" aria-modal="true" aria-labelledby="participation-title">
        <button className="modal-close" type="button" onClick={onClose} aria-label="Fermer">
          <X size={20} />
        </button>
        {submittedParticipant ? (
          <div className="success-view">
            <div className="modal-heading">
              <span className="eyebrow">C’est confirmé</span>
              <h2 id="participation-title">J’y serai<span> !</span></h2>
              <p>Ton portrait rejoint la galerie. Voici ta carte de participation à partager autour de toi.</p>
            </div>
            <div className="personalized-poster" aria-label="Aperçu de l’affiche personnalisée">
              <img className="personalized-poster-base" src={OFFICIAL_POSTER_URL} alt="Affiche officielle du FECAWA" />
              <img className="personalized-poster-photo" src={submittedParticipant.photoUrl} alt="Ton portrait dans l’affiche personnalisée" />
            </div>
            <div className="share-actions">
              <button className="primary-button" type="button" onClick={downloadPoster}><Download size={17} /> Télécharger</button>
              <button className="share-button" type="button" onClick={() => sharePoster("whatsapp")}><MessageCircle size={17} /> WhatsApp</button>
              <button className="share-button" type="button" onClick={() => sharePoster("facebook")}><Share2 size={17} /> Facebook</button>
              <button className="share-button icon-share" type="button" aria-label="Copier le lien" onClick={() => sharePoster("copy")}><Link2 size={17} /><Copy size={14} /></button>
            </div>
            <p className="modal-footnote">L’affiche officielle est conservée ; seule la zone photo est remplacée.</p>
          </div>
        ) : <>
        <div className="modal-heading">
          <span className="eyebrow">Ta place dans l’histoire</span>
          <h2 id="participation-title">J’y serai<span>.</span></h2>
          <p>Ajoute ton portrait et rejoins la communauté visuelle du FECAWA.</p>
        </div>

        <button className={`upload-zone ${preview ? "has-preview" : ""}`} type="button" onClick={() => inputRef.current?.click()}>
          {preview ? (
            <img src={preview} alt="Aperçu de ta participation" />
          ) : (
            <>
              <span className="upload-icon"><Upload size={20} /></span>
              <strong>Ajouter ma photo</strong>
              <span>JPG, PNG, WebP · 10 Mo max.</span>
            </>
          )}
          {preview && <span className="change-photo">Changer la photo</span>}
        </button>
        <input ref={inputRef} className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" capture="user" onChange={(event) => handleFile(event.target.files?.[0])} />

        <label className="field-label" htmlFor="participant-name">Nom et prénom <span>(facultatif)</span></label>
        <input id="participant-name" className="text-field" type="text" maxLength={120} placeholder="Ex. Amina K." value={name} onChange={(event) => setName(event.target.value)} />

        <label className="consent-row">
          <input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} />
          <span className="custom-checkbox">{consent && <Check size={13} strokeWidth={3} />}</span>
          <span>J’autorise la publication de ma photo dans la galerie des participants.</span>
        </label>

        {error && <div className="form-error"><CircleAlert size={16} />{error}</div>}
        <button className="primary-button full-width" type="button" disabled={submit.isPending} onClick={handleSubmit}>
          {submit.isPending ? "Envoi en cours…" : "Confirmer ma participation"}
          {!submit.isPending && <ArrowUpRight size={18} />}
        </button>
        <p className="modal-footnote">Ta photo est recadrée au format carré et compressée automatiquement avant envoi.</p>
        </>}
      </div>
    </div>
  );
}

function ParticipantCard({ participant, index }: { participant: Participant; index: number }) {
  return (
    <article className="participant-card" style={{ "--delay": `${index * 45}ms` } as React.CSSProperties}>
      <div className="participant-image-wrap">
        <img src={participant.photoUrl} alt={participant.name ? `Portrait de ${participant.name}` : "Participant au FECAWA"} />
        <span className="participant-badge"><Sparkles size={11} /> J’y serai</span>
      </div>
      {participant.name && <p>{participant.name}</p>}
    </article>
  );
}

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const participantsQuery = trpc.participants.list.useQuery();
  const participants = (participantsQuery.data ?? []) as Participant[];
  const participantCount = useMemo(() => Math.max(participants.length, 0), [participants.length]);

  const openParticipation = () => {
    setIsMenuOpen(false);
    setIsModalOpen(true);
  };

  const closeParticipation = () => setIsModalOpen(false);

  return (
    <div className="fecawa-site">
      <header className="site-header">
        <a href="#accueil" className="brand-mark" aria-label="FECAWA, accueil">
          <span className="brand-symbol">F</span>
          <span className="brand-wordmark">FECAWA</span>
        </a>
        <nav className={`site-nav ${isMenuOpen ? "is-open" : ""}`} aria-label="Navigation principale">
          {navItems.map((item) => (
            <a key={item.href} href={item.href} onClick={() => setIsMenuOpen(false)}>{item.label}</a>
          ))}
          <button className="nav-cta" type="button" onClick={openParticipation}>J’y serai <ArrowUpRight size={16} /></button>
        </nav>
        <button className="menu-toggle" type="button" aria-label={isMenuOpen ? "Fermer le menu" : "Ouvrir le menu"} onClick={() => setIsMenuOpen((open) => !open)}>
          {isMenuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </header>

      <main>
        <section id="accueil" className="hero-section section-shell">
          <div className="hero-copy">
            <div className="eyebrow reveal">Festival des Arts et de la Culture Waama</div>
            <h1 className="reveal reveal-delay-1">Une présence.<br /><em>Une mémoire.</em><br />Un mouvement.</h1>
            <p className="hero-intro reveal reveal-delay-2">Le FECAWA se vit ensemble. Affirme ta présence, partage ton portrait et fais partie de la galerie des participants.</p>
            <div className="hero-actions reveal reveal-delay-3">
              <button className="primary-button" type="button" onClick={openParticipation}>J’y serai <ArrowUpRight size={18} /></button>
              <a className="text-link" href="#festival">Découvrir le festival <ChevronRight size={17} /></a>
            </div>
            <div className="hero-note reveal reveal-delay-4"><span className="note-line" />Une identité, une communauté</div>
          </div>
          <div className="hero-poster reveal reveal-delay-2">
            <OfficialPoster />
            <div className="poster-caption"><span>01</span><span>Affiche officielle du FECAWA</span></div>
          </div>
          <a className="scroll-cue" href="#festival" aria-label="Faire défiler vers le festival"><span>Défiler</span><ArrowDown size={16} /></a>
        </section>

        <section id="festival" className="festival-section section-shell">
          <div className="section-intro">
            <span className="eyebrow">Le festival</span>
            <h2>Le Waama en <em>présence.</em></h2>
          </div>
          <div className="festival-content">
            <div className="festival-number">02</div>
            <div className="festival-copy">
              <p className="large-copy">Du 19 au 21 novembre 2026, le FECAWA se retrouvera à Natitingou.</p>
              <p className="muted-copy">La culture nous rassemble. L’affiche officielle présente le Festival des Arts et de la Culture Waama et devient ici la base de chaque affiche personnalisée.</p>
              <div className="detail-grid">
                <div><span>Dates</span><strong>19 — 21 novembre 2026</strong></div>
                <div><span>Lieu</span><strong>Natitingou</strong></div>
              </div>
            </div>
            <div className="festival-mark"><span>F</span><span>W</span><span>A</span></div>
          </div>
        </section>

        <section id="participer" className="participation-section section-shell">
          <div className="participation-card">
            <div className="participation-orbit orbit-one" />
            <div className="participation-orbit orbit-two" />
            <div className="participation-text">
              <span className="eyebrow">03 / Participation</span>
              <h2>J’y serai !<br /><em>Et toi ?</em></h2>
              <p>Une photo suffit pour laisser une trace. Rejoins les visages qui feront vivre le FECAWA.</p>
            </div>
            <div className="participation-action">
              <button className="light-button" type="button" onClick={openParticipation}><ImagePlus size={19} /> Ajouter ma photo <ArrowUpRight size={18} /></button>
              <span>2 minutes · depuis ton téléphone</span>
            </div>
          </div>
        </section>

        <section id="participants" className="participants-section section-shell">
          <div className="section-heading-row">
            <div>
              <span className="eyebrow">La communauté</span>
              <h2>Ils ont dit : <em>J’y serai !</em></h2>
            </div>
            <div className="participant-count"><strong>{participantCount.toString().padStart(2, "0")}</strong><span>participants<br />dans la galerie</span></div>
          </div>
          {participantsQuery.isLoading ? (
            <div className="gallery-empty"><div className="loading-dot" /><span>La galerie se prépare…</span></div>
          ) : participants.length > 0 ? (
            <div className="participant-grid">{participants.map((participant, index) => <ParticipantCard key={participant.uid} participant={participant} index={index} />)}</div>
          ) : (
            <div className="gallery-empty"><ImagePlus size={25} /><strong>La galerie commence avec toi.</strong><span>Sois le premier visage à dire : J’y serai.</span><button className="outline-button" type="button" onClick={openParticipation}>Ajouter ma photo <ArrowUpRight size={16} /></button></div>
          )}
        </section>

        <section id="contact" className="contact-section section-shell">
          <div className="contact-card">
            <div><span className="eyebrow">04 / Contact</span><h2>Le festival<br /><em>se construit ensemble.</em></h2></div>
            <div className="contact-side"><p>Les coordonnées officielles seront ajoutées ici depuis l’affiche du FECAWA.</p><a href="#accueil" className="text-link">Retour en haut <ArrowUpRight size={17} /></a></div>
          </div>
        </section>
      </main>

      <footer className="site-footer"><div className="footer-brand"><span className="brand-symbol">F</span><div><strong>FECAWA</strong><span>Festival des Arts et de la Culture Waama</span></div></div><div className="footer-links"><a href="#festival">Le festival</a><a href="#participer">J’y serai</a><a href="#participants">Participants</a><a href="#contact">Contact</a></div><div className="footer-social"><a href="#contact" aria-label="Instagram"><Instagram size={17} /></a><a href="#contact" aria-label="WhatsApp"><MessageCircle size={17} /></a></div><div className="footer-bottom"><span>© FECAWA</span><span>Une présence. Une mémoire. Un mouvement.</span></div></footer>

      {isModalOpen && <ParticipationModal onClose={closeParticipation} onSuccess={() => { void participantsQuery.refetch(); }} />}
    </div>
  );
}
