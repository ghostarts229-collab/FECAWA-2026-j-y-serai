import { describe, expect, it } from "vitest";
import { participationInput } from "./routers";

describe("participants.submit validation", () => {
  it("accepts a compressed JPEG data URL with consent", () => {
    const result = participationInput.safeParse({
      name: "Amina K.",
      imageData: "data:image/jpeg;base64,ZmVjYXdh",
      consent: true,
    });

    expect(result.success).toBe(true);
  });

  it("rejects unsupported file formats", () => {
    const result = participationInput.safeParse({
      imageData: "data:image/gif;base64,ZmVjYXdh",
      consent: true,
    });

    expect(result.success).toBe(false);
  });

  it("requires explicit publication consent", () => {
    const result = participationInput.safeParse({
      imageData: "data:image/png;base64,ZmVjYXdh",
      consent: false,
    });

    expect(result.success).toBe(false);
  });

  it("limits participant names to 120 characters", () => {
    const result = participationInput.safeParse({
      name: "x".repeat(121),
      imageData: "data:image/webp;base64,ZmVjYXdh",
      consent: true,
    });

    expect(result.success).toBe(false);
  });
});
