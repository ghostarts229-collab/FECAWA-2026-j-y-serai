import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertParticipant, InsertUser, participants, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getApprovedParticipants() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: participants.id, uid: participants.uid, name: participants.name, photoUrl: participants.photoUrl, createdAt: participants.createdAt })
    .from(participants)
    .where(eq(participants.status, "approved"))
    .orderBy(desc(participants.createdAt))
    .limit(60);
}

export async function getAllParticipants() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(participants).orderBy(desc(participants.createdAt)).limit(500);
}

export async function insertParticipant(participant: InsertParticipant) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.insert(participants).values(participant);
  const rows = await db.select().from(participants).where(eq(participants.uid, participant.uid)).limit(1);
  return rows[0];
}

export async function updateParticipantStatus(id: number, status: "pending" | "approved" | "rejected" | "hidden") {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.update(participants).set({ status }).where(eq(participants.id, id));
}

export async function removeParticipant(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.delete(participants).where(eq(participants.id, id));
}
