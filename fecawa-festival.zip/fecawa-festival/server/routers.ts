import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { nanoid } from "nanoid";
import { z } from "zod";
import { storagePut } from "./storage";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { getAllParticipants, getApprovedParticipants, insertParticipant, removeParticipant, updateParticipantStatus } from "./db";

const acceptedMimeTypes = ["image/jpeg", "image/png", "image/webp"] as const;
export const participationInput = z.object({
  name: z.string().trim().max(120).optional(),
  imageData: z.string().regex(/^data:image\/(jpeg|png|webp);base64,/, "Format d’image non pris en charge."),
  consent: z.literal(true),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  participants: router({
    list: publicProcedure.query(() => getApprovedParticipants()),
    submit: publicProcedure.input(participationInput).mutation(async ({ input }) => {
      const [header, encoded] = input.imageData.split(",");
      if (!header || !encoded) throw new TRPCError({ code: "BAD_REQUEST", message: "Photo invalide." });
      const mimeType = header.match(/^data:(image\/(?:jpeg|png|webp));base64$/)?.[1];
      if (!mimeType || !acceptedMimeTypes.includes(mimeType as (typeof acceptedMimeTypes)[number])) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Format d’image non pris en charge." });
      }
      const buffer = Buffer.from(encoded, "base64");
      if (!buffer.length || buffer.length > 5 * 1024 * 1024) {
        throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "La photo compressée doit faire moins de 5 Mo." });
      }
      const uid = nanoid(16);
      const extension = mimeType === "image/jpeg" ? "jpg" : mimeType.split("/")[1];
      const stored = await storagePut(`fecawa/participants/${uid}.${extension}`, buffer, mimeType);
      const participant = await insertParticipant({
        uid,
        name: input.name?.trim() || null,
        photoUrl: stored.url,
        photoKey: stored.key,
        status: "approved",
        consent: 1,
      });
      return { participant };
    }),
    adminList: adminProcedure.query(() => getAllParticipants()),
    setStatus: adminProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["pending", "approved", "rejected", "hidden"]) })).mutation(async ({ input }) => {
      await updateParticipantStatus(input.id, input.status);
      return { success: true } as const;
    }),
    remove: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => {
      await removeParticipant(input.id);
      return { success: true } as const;
    }),
  }),
});

export type AppRouter = typeof appRouter;
